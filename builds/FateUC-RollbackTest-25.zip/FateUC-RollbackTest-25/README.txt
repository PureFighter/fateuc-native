Fate/unlimited codes - native PC port with rollback netplay - RELEASE 1.3 (test 25)
===================================================================================

####################################################################################################################
NO GAME FILES HERE. This zip contains none of Fate/unlimited codes' files or data: no disc image, no graphics,
sound, music, movies, text or saves. YOU NEED YOUR OWN COPY OF THE GAME: the port runs from your own disc image
every time it starts, and it does nothing without it. Never share disc images or game files, and don't ask for them.
How it works: ps2run.exe is the game's program, recompiled into a native PC program with ps2-native-recomp;
everything it shows and plays is read from your disc image.
####################################################################################################################

The native PC port of Fate/unlimited codes (PS2, Japan, SLPM-55108) with rollback netplay (GekkoNet). Release 1 was
its first public release, and this is Release 1.3: https://github.com/PureFighter/fateuc-native has the downloads,
the tester guide and the reports. Both players need Release 1.3: it doesn't play with Release 1.2 or older.

New in Release 1.3
- Cross confirms and Circle goes back, in the game's menus and in ours:
  - In the game's own menus (title, main menu, character and stage select, OPTION, the pause menu, after a match and
    the vote) Cross confirms and Circle goes back. In a fight the buttons keep their meaning (Circle H, Cross RG).
  - The game's own pictures of the buttons still show its PS2 way: a circle beside "decide", a cross beside "back".
  - In the game's CONTROLLER SETTINGS the button you press is the button you set, so Cross and Circle are not
    swapped there.
  - Our menus too: the F1 menu, the practice menu, Change keys, Controllers, MATCH READY and the game's own launcher
    window (ps2run.exe started by itself). On the keyboard Enter and Esc work as before, and so do the keys of Cross
    and Circle (J and K).
  - keys.ini menu_confirm = circle brings back the old way (Circle confirms) in the game's menus and ours.
- The game's own button settings are kept:
  - The game's CONTROLLER SETTINGS (in OPTION, and in the pause menu during a fight) are now kept on this PC, in
    keys.ini's game_buttons_p1 and game_buttons_p2 lines, and used in Play offline, practice, Host/Join and rooms.
  - Online each player keeps their own: the two games send them to each other when they connect, and the game's
    screen shows each player's own layout. Replays and watchers (late ones too) get both layouts with the match.
  - Change them in the game as on a PS2; the change is kept at once. F1 > Change keys and Controllers still decide
    which key or controller button is which PS2 button; the game's settings decide what that button does in a fight.
- The score after a match: while both players pick Rematch, Character Select or Main Menu, the vote shows each
  player's match wins in this session on their own side, player 1's on the left and player 2's on the right (in a
  room, the set's score). Watchers see the same score.
- Menus:
  - The chosen line of the F1 and practice menus has a see-through white-grey bar (keys.ini menu_highlight = amber:
    the old amber bar). L1 and R1 switch the menu's tabs, and so do Tab and the keys of L1 and R1 (P and O).
  - Long lists have two levels: Change keys and the practice move list. Cross goes into the list (it gets a slightly
    lighter ground; ^ and v show there is more), Up and Down move and scroll, Circle comes back out.
- New default keys for a new keys.ini: W A S D move (the D-pad; the arrow keys too), U Square (L), I Triangle (M),
  J Cross (RG), K Circle (H), O R1, P L1, L R2, ; L2, Esc Start, Tab Select. No mouse button presses a game button.
  An existing keys.ini keeps your keys: F1 > Change keys > Put back the default keys takes the new ones.
- The disc image is checked: an .iso that isn't Fate/unlimited codes (SLPM-55108), such as an Android installer or
  another game's disc in the same folder, is passed over. The launcher and the game's own window take only this
  game's .iso, next to the game or in the folder above, and say which files they passed over and why (the .bat files
  skip them too); a file you choose that isn't the game is refused. Started with one anyway, the game says so and
  stops at once (exit code 9).
- The launcher (FateUC.exe 0.8.1): Report a problem is at the bottom right of its window on every tab (it needs a
  GitHub account, as the note beside it says); before any session it shows the launcher's log to attach. After
  "4. Older settings" copies a keys.ini, it says how to get the new default keys.
- Release 1.3 doesn't play with Release 1.2 or older (the game's simulation changed): both players need 1.3, with
  codes and in rooms. To update, close the game and the launcher, then copy this folder's files over your Release
  1.2 folder (your keys, settings, name and history stay), or use a new folder: at its first start,
  "4. Older settings" brings your keys, controller settings and disc choice from the old one.

New in Release 1.2
- Practice no longer freezes when you choose a stage, and quitting no longer leaves the game stuck in Windows until
  Task Manager ends it. Both came from one wait in the game's drawing queue that could miss its wake-up while a
  stage loaded; the game then waited forever. That wait is fixed, and every wait between the game's parts now ends
  when the game stops.
- Quitting always ends the game: a game still running 8 seconds after you quit (30 while it is still writing a save
  or saying goodbye to the other player) ends itself with exit code 8, and its log says what was still running.
- The launcher (FateUC.exe 0.7.0) and the game stay in step:
  - A game started by hand (ps2run.exe), or one stuck after quitting, no longer makes the launcher's starts do
    nothing. The launcher says "Started outside the launcher" and offers Close it (End it... if the game doesn't
    close), Show it or Leave it; once that game is gone, your start goes on by itself. A game from another folder
    never blocks this one.
  - Requests and replies left in data\ by an earlier start are set aside (renamed .stale), and the game only acts on
    a request written for this start, so nothing left over can close or start the wrong game. One game per folder
    reads the launcher's requests.
  - When the game doesn't start, the launcher says why and what to do: no disc chosen or not where it was, a missing
    file, a game already running, Windows refused to start it, or the game closed right away (with the exit code's
    words and Report a problem).
  - The launcher never overwrites the game's own files (keys.ini, the controller files, launcher.ini) and never
    keeps them open; at its first start, "4. Older settings" copies them only where this folder has none, and now
    brings controller_layouts.txt too (F1 > Controllers > Button layout).
- Saving your controls and settings:
  - keys.ini, controller_layouts.txt and controller_buttons.txt are saved at each change as a whole file (a
    temporary file, then a rename), so a game that crashes or is ended in Task Manager never leaves half a file.
  - A keys.ini the game can't read is no longer replaced with the default keys; the screen says so instead.
  - A save that fails shows on screen whatever "notices" says: "Settings not saved", the file and why (a read-only
    folder, Program Files, Windows Security's folder protection, a full disk). The change still works until you
    quit.
  - Controller layouts and "several buttons" now load and save when the game's folder path has non-English letters.
  - ps2run.exe started by hand without --game-dir now uses the data folder next to it, like the launcher.
  - Up to Release 1.2 the game's own BUTTON CONFIG (OPTION in the game's menu) was not kept in practice, online or
    Play offline, and the game said so once; Release 1.3 keeps it.
- Choppy sound at moves like Saber's 236L: we couldn't make it happen here, but a likely cause is that the first
  time a run meets an effect, the graphics card's program for it is still being made, and the processor draws that
  effect meanwhile, which can make frames late. Release 1.2 keeps the list of those programs in
  data\hw\pipelines.txt and makes them before the game starts, from the second start on. If the sound still
  stutters, please report it: the log now says what each stutter waited for (the disc, the picture, the sound).
- 11 more of the game's VU1 programs (met on stages 1, 3, 4, 5 and 10) are now built in, instead of running in the
  slower interpreter.
- Rooms and Host/Join:
  - The room service answers the launcher's ping; a launcher it hasn't heard from for 70 s counts as away.
  - A player back from a dropped connection takes the seat that waited; a match whose opponent left first ends
    instead of holding the room.
  - A comeback the room service refuses leaves the room at once with words, instead of a minute of "Coming back...".
    A slow or unreachable service is explained: the time limit, the internet connection, a firewall, or the PC's
    date.
  - Sit, Accept or a start pressed twice counts once, and closing the launcher in a room leaves the room first.
- Release 1.2 didn't play with Release 1 or 1.1 (the game's simulation changed).

New in Release 1.1
- The sound is quieter by default: 75% of its level up to Release 1. A line in data\keys.ini sets your own level
  from 0 to 100 when the game starts: "volume = 100" is as loud as before, "volume = 60" quieter still. The key
  tones (F5, F8, F9) follow it too.
- Shorter credits (CREDITS.txt, also in the launcher's Settings > About): PureFighter, the projects this port is
  built on, and one line on how it was made.
- Release 1.1 played with Release 1, with codes and in rooms.

New in Release 1
- The screen shows the game, not the test: no ROLLBACK TEST words in the corner line or in the window title (the
  title is "Fate/unlimited codes", the version and your session), no connection report panel after a match or when
  a session ends, and notices that come by themselves (controllers found, connected, back or away; settings changed
  in the F1 menu) go to the log only.
- Still on screen: answers to your own keys (F5, F8, F2, the practice keys), MATCH READY and the launcher's answer
  when you accept or decline there instead ("You accepted in the launcher."), the session's messages, the vote,
  WATCHING and both players' names, and the corner line (F4 hides it).
- A joystick that waits for its Start button still shows that hint when no fight runs.
- Everything that left the screen is in the log (and the connection report in its files too), so a report zip
  says what you would have seen.
- To get test 22's screen back, add any of these lines to data\keys.ini:
    labels = test                 the ROLLBACK TEST words, and the speed numbers in the window title
    after_match_report = screen   the connection report's panel after each match and at the session's end
    notices = screen              every notice in the title and over the picture
  and launcher_notices = log puts the launcher's answers in the log only.
- Report a problem, in the launcher (FateUC.exe 0.6.0): on the Reports tab, and after a session or a room match. It
  opens a new issue on the release's page with the build, your setup, the ping and your PC filled in, and opens the
  folder with your report zip selected: write what happened and drag both players' zips in. It sends nothing by
  itself, and it leaves out names, codes, addresses and your Windows user folder. Issues there are public.
- The launcher names the build by its label, Release 1 (test 23); a room match now packs a report zip too.
- The code server has a new address, built into this release. Test builds up to 22 can no longer use its 5-digit
  codes or rooms (their long codes still work).
- licenses\ also holds the licence that comes with dxil.dll (Microsoft's DirectX shader compiler).

From test 22: rooms for up to 8, watching, and practice while you wait
- Rooms, in the launcher's new Room tab: one player makes a room (up to 8 players; who stays after a set; first to
  1, 2 or 3) and gets a 6-digit room code; the others join with it. The room has two seats: Sit takes a free seat,
  or a place in the queue. When both seats are full, both players get MATCH READY with 20 seconds to accept; when
  both accept, the match starts by itself (no codes to type). Declining, or no answer, takes you out of the seat and
  the queue until you sit again.
- After a set, the room's rule decides who stays: the winner (the default), the loser, or both leave; the next in
  the queue sits. The room shows each player's wins and losses in the room, and the set's score as it goes.
- Everyone who isn't seated watches the match live, a moment behind, in their own game window, which opens by itself
  ("Stop watching" in the Room tab turns that off). A late watcher's game catches up at speed from the session's
  start, then plays live. Watchers' controllers never reach the match.
- Practice while you wait: Practice from the Room tab. When your match is ready, MATCH READY appears inside the
  practice game too (accept: Start, Enter or Cross; decline: Select, Esc or Circle, named as your controller names
  them); on accept the launcher closes practice and starts the match.
- The room's owner can change its rules and remove a player. Only the seated player 2 ever gets the match's own
  code, never shown on screen, and nobody in a room sees anyone's address.
- Online sessions keep a replay again, with only the frames both games agreed on; the watching stream is player 1's.
- The room service runs on the same code server as the 5-digit codes, which work as before.

Release 1.3 plays only with Release 1.3 (test 25), with codes and in rooms. Rooms need this release and the launcher
in this zip (FateUC.exe 0.8.1); an older game in a room's folder is told what it needs.

From test 21: the launcher in the zip, your name, the practice menu in tabs
- The launcher is now part of the zip: double-click FateUC.exe (version 0.4.0 in test 21, 0.5.0 in test 22, 0.6.0 in
  Release 1, 0.7.0 in Release 1.2, 0.8.1 in Release 1.3). Its first start checks the game and your disc and asks for
  your name, the one the other player sees; it is sent only after you have seen it. Its pages: Home (Play offline
  and Practice), Host, Join, Room (test 22), History, Reports and Settings. ps2run.exe still opens the game's own
  window as before.
- Settings > Profile: your name (Change name), since when the profile exists, and your online stats: sessions,
  matches, wins and losses, rounds, your most played characters, time online, opponents. Delete profile removes the
  name, the stats and the history (the game's settings and keys stay). Nothing of it leaves your PC but the name.
- History: your online sessions, newest first: who, ping and input delay, and each match's characters, result and
  rounds. Earlier test folders' sessions are read at the first start, when they are still there.
- The F1 menu (and Start in practice) in tabs. Practice: Basic training (the dummy's CPU ACTION, GUARD and COUNTER
  HIT first, then the gauges, the recovery, characters and stage, the move list, the game's own PRACTICE MENU, the
  displays), Record and playback (slots, recording, playback), Game (resume, saves, keys, controllers, quit) and
  Display Settings (the picture). Tab and Shift+Tab, or L1 and R1 (LB and RB), change tabs; the menu opens on the
  tab it was last on. keys.ini menu_layout = round24 gives back the one list of test 20.
- The dummy breaks throws whenever it guards, so there is no THROW BREAK row: GUARD OFF never, RANDOM about half the
  time, every other GUARD always.
- Characters and stage: Enter on a choice swaps at once; Back or closing the menu with other choices swaps too. No
  "Swap now" to find.
- Online, both players' names show under the characters' banners during the rounds. F4 hides them with the corner
  line.
- "Controller connected", "Saved" and the like show lower down, in the middle and smaller, so they don't cover the
  fight (keys.ini message_place = top puts them back at the top).
- CREDITS.txt (also in the launcher's Settings > About) names everyone who built this port.

From test 20: less input delay online, in two feels: Responsive and Smooth
- With the input delay on auto (the default), the game now picks it from the ping and from how fast both PCs are:
  each PC measures itself during the fights, and the slower one sets the limit. With two fast PCs that is a frame or
  two less than test 19 at most distances (for example 2 instead of 3 at 150 ms of ping); with a slower PC the game
  can choose more than test 19, so that PC keeps up.
- Responsive (the default): the least delay both PCs keep up with. Your moves come out sooner, but at a long
  distance the game corrects the picture more often (a character can jump into place).
- Smooth: one frame more where that makes those corrections shorter, so the pictures jump less. At short distances
  the two are the same. If either player picks Smooth, the session plays Smooth.
- The first round of a session plays at test 19's delay while both PCs measure themselves; from the next round on
  the game uses what they measured. The delay changes only while a match loads and as a round begins, never in a
  fight, and both games change at the same moment.
- Where to choose: in the new launcher (FateUC.exe, version 0.3.0 or later, for those who have it): Settings >
  Online. Without it: the Host and Join .bat files have a line for it, or put auto_delay = smooth (or responsive) in
  data\keys.ini. The game remembers the last choice in that line until you choose again, so ps2run.exe's own
  window uses it too.
- The corner line (F4) shows the feel after the delay, for example "delay 2 (Responsive)", and so does player 1's
  window while it waits. netplay.log has a line at each change: the ping, both PCs' measured speed, both feels, the
  delay and what set it.
- A fixed delay (1 to 10) works as before and ignores the feel.

From test 19: the stick display and the input history as an arcade stick
- Both now show the eight buttons as an arcade stick, two rows of four: Square/X, Triangle/Y, R1/RB, L1/LB on top;
  Cross/A, Circle/B, R2/RT, L2/LT below.
- Names and colours follow your device. Xbox pads (and pads Windows sees as one): X blue, Y yellow, A green, B red.
  PlayStation pads, the keyboard and other devices: Square pink, Triangle green, Circle red, Cross blue. Shoulder
  buttons are grey; a pressed button is filled. keys.ini button_labels = auto | xbox | playstation (DS4Windows
  users: playstation, for PlayStation names on a pad Windows sees as an Xbox pad).
- The stick display sits at the bottom left for player 1 and at the bottom right for player 2, above the game's
  gauges. The input history shows 8 lines. keys.ini input_layout = round23 brings back test 18's layouts.

From test 19: practice remembers your settings, and Start opens the menu
- Your practice settings (the dummy's page, the slot, the recording's length and playback, where they begin, input
  history, frame data, stick display) are kept in data\keys.ini and come back at the next practice start. The
  practice page's last line puts them back to their defaults. Save slots and recordings stay in memory only.
- In a practice fight, a tap of Start (Esc on the keyboard) opens our menu. Its first page now has Move list and the
  game's own PRACTICE MENU (not while a recording or playback runs: the state line says so). What you change in the
  game's menu is kept with the rest of the dummy's settings. keys.ini practice_start = game: Start goes to the game
  as before. Outside a practice fight, and online, Start always goes to the game.
- A small line at the bottom says "Start: Menu   Select: Reset" in your device's names (icons on an Xbox pad).
  Select is the game's own reset: both fighters back to their start marks, full life, magic gauges at one bar. It
  works mid-combo, during a super, in the air, while recording and during playback. While recording, Select now
  resets without going onto the recording, so a playback never resets the game.

From test 19: the dummy recovers when your combo drops
- Practice > The dummy: "Recovery in the air" and "Recovery on the ground" are the game's AIR / GROUND PASSIVE MOVE.
  With any value but OFF, the dummy recovers at the first frame the game allows, as the hit counter turns blue (the
  game's sign that the combo dropped). In a true combo the counter stays red and the dummy doesn't recover.
- In the air: NORMAL recovers in place, FRONT toward you, BACK away from you. On the ground: NORMAL gets up in
  place, FRONT rolls toward the camera, REAR away from it. RANDOM: one in four each for none, NORMAL, FRONT and BACK
  or REAR. OFF by default, as in the game.
- Frame data: Saber's 6M now shows as a hit (not a whiff), a follow-up that misses a juggled dummy as a whiff, and a
  hit cancelled into a special on the frame it lands as a hit. After a recovery, advantage counts to the frame the
  dummy is free.

From test 18: every character's move list in practice
- F1 > Practice > Move list now has all 17 characters (Saber Lily and the third colours use their character's list),
  read from the game's own COMMAND LIST: every move with its input drawn as arrows and button icons, for a player
  facing right. Left / Right: player 2's. Up / Down scrolls. Long names and inputs continue on the next line.
- The names follow the Mizuumi wiki (mizuumi.wiki) where we had its pages; Archer's follow Shirou's page, and Saber
  Alter, Luviagelita and Bazett keep our own English. The words follow the wiki too: "Magic Burst" (what we called
  Magic Release), and RG is Reflect Guard. Sakura's SP-B is "I'm hungry".
- Tell us any name or input that doesn't match the game.

From test 17: Main Menu ends the session
- After a match, Main Menu (either player, at once) now ends the session on both PCs: both games say who chose it
  ("Player 2 chose Main Menu: the session is over."), show the connection report of the whole session, and close by
  themselves a few seconds later, so the launcher that started them comes back. Rematch and Character Select are as
  before.
- The game's own ways to its main menu do the same: RETURN MAIN MENU in the game's menu after a match (when player 1
  chooses, without the vote), and RETURN MAIN MENU in the pause menu during a fight.
- The old way (both games go to the game's main menu and the session goes on): the line
  set "PS2X_POSTMATCH_MAINMENU=game" in the Host or Join .bat file (one player's line is enough).

From test 16: getting through more routers, IPv6, and your home network
- IPv6: when both PCs have IPv6 internet, the games call each other over it first. No router port is needed then,
  and a strict router doesn't matter. The window says "IPv6 on this PC: yes" or "no". Room codes carry IPv6 by
  themselves; with IPv6 the long code is longer (45 letters and digits): copy it with C and paste it with Ctrl+V.
- Player 1's router can now open the game's port with PCP or NAT-PMP when UPnP opens nothing (some Apple and OpenWrt
  routers, for example). The window then says "Your router opened port 7000 for this game (PCP; ...)" and player 2
  needs only the room code or the long code.
- One strict router (a new outside port for every destination) against one that keeps ports now connects: the games
  try many ports at once, usually for a few seconds, at most for a minute, then the window says what else works. A
  router or a security program may log those many small packets as a port scan: that is this game, not an attack.
  Both routers strict still needs a VPN or a forwarded port.
- The windows say in plain words what the routers allow: whether player 1's router opened a port (UPnP, PCP or
  NAT-PMP) or your provider shares your address, whether each router keeps ports or is strict, and once the other
  player's code is in, what the two of you can do.
- Same home, no code: while player 1 hosts, the game tells your home network so (nothing goes past your router, and
  no address is shown). In player 2's Join box a line says "Player 1's game is waiting on your home network": press
  Tab (Triangle on a controller) to join it.
- After both players connect, the black screen says "Starting the match..." until the character select is up.
- The launcher's Host and Join pages have "Start at: character select / the menus". If either player picks the
  menus, both games start through the menus, as before test 15.
- A typo in an address given to the game is now explained in the game's Join box, where you can type it again.

From test 16: frame data and throw breaks in practice
- Frame data: a panel at the top shows each side's last move: its startup, active, recovery and total frames, and
  how it ended: "on block -3", "on hit +2", "KD +62" (a knockdown; "KD" alone: still down), "whiffed", "throw
  broken", or "cancelled" (a chain or a cancel). Green: that side can act first; red: the other side can. Moves have
  no names yet, only numbers. F1 > Practice > Frame data turns it on or off (on at first; your choice is kept).
- THROW BREAK (F1 > Practice > The dummy, after GUARD): AUTO breaks every throw it can while GUARD is ALL or 1ST HIT
  ONLY; ON always; OFF never; RANDOM on the game's own coin.
- GUARD has a new value, 1ST HIT ONLY: the dummy blocks the first hit, then can't block until it's free again.
- To break a throw yourself: press L+M with forward or back, 3 to 10 frames after the thrower pressed. Holding L+M
  early doesn't work: it comes out as M.
- CPU ACTION in our menu and in the game's own PRACTICE MENU now stay the same.

From test 16: for the coming launcher (nothing to do for you yet)
- ps2run.exe --version prints one line about this build (for the new launcher's update check) and ends: no window,
  no disc, nothing written.
- Each session folder (data\logs\rollback_test_...) also holds session.json: what the new launcher will show while
  you play (waiting, playing, how it ended). It holds no address; player 1's codes only while it waits, and never
  when they are hidden. The report keeps it with both codes emptied.
- tools\exit-codes.json holds the words for the game's exit codes (the launcher and the report read it).
- The test lines are command-line options too (--netplay-trace, --netplay-same-shape, --netplay-mixed-rule old,
  --widescreen-fov 0.75, --netplay-after-match player1); the old .bat lines still work.
- The logs now say what kind of connection player 2 came over (this PC, home network, VPN, internet, IPv6), not its
  address.

From test 15: 5-digit room codes
- Player 1 chooses Host online, then Start hosting. A few seconds later the game window shows a room code in big
  digits, for example "Room code 48213", and "Player 2 types it in Join online". C copies it (Triangle on a
  controller). Send those 5 digits to player 2.
- Player 2 chooses Join online, then Start joining, types the 5 digits in the game window and presses Enter. That is
  all: no second code to send back. The two games find each other through our code server, then connect directly
  to each other, as before (the code server never sees the match).
- Under the room code, player 1's window still shows the long code (16 letters and digits). It works as in test 14,
  without the code server: if the room code doesn't work, player 2 types the long code instead (and you swap codes
  if the window asks for it).
- A room code is for one meeting: it closes when the match starts or when player 1 stops hosting. Host again for a
  new one. If player 2 cancels or can't get through, the same room code still works for the next try. If nobody
  joins within 15 minutes, player 1's window gets a new room code by itself.
- If you both chose Host: either of you types the other's room code in your own game window (Enter, type the 5
  digits, Enter). Your game stops hosting and joins the other one. Typing your own room code there tells you so.
- Both PCs in the same home: the room code works there too (the games use your home network's addresses for that,
  and never show them).
- "Hide my code and address" (for streaming) hides the room code too: it shows as *****, and C still copies it.
  Anyone who sees a room code can take player 2's place, so send it only to the other player.

What the windows can say
- "No room has this code. Check the 5 digits with player 1, or ask for a new code."
- "This room already has player 2. Ask player 1 for a new code."
- "The code server can't be reached": the code server is down or something blocks it. Use the long code.
- "This game and the code server don't speak the same version: get the newest test build."
- "Too many tries from your address: wait N minute(s)." (after 10 wrong codes in 10 minutes, for example)
- "Player 1 left: the room closed (player 1 stopped hosting, or their game closed). Ask player 1 for a new room
  code." Or, when player 1's game stopped answering for 15 seconds: "Player 1 left: their game stopped answering the
  code server (it closed, or lost its connection). Ask player 1 to host again."
- On player 1's side: "Player 2 left. Your room code still works: another player 2 can type it."
- After 30 seconds without getting through: "Your two routers need the relay, which comes in the next test.
  Meanwhile: a VPN (Radmin VPN, ZeroTier, Tailscale), or forward UDP port 7000 to player 1's PC." Some pairs of
  routers can't connect directly at all; the next test sends those games through a relay server.

The code server (keys.ini and the launcher)
- The launcher's Settings page has a new line, "Code server": auto (the game's own code server, shown by its name),
  off (the long codes only, exactly as in test 14), or custom. The same is the code_server line in data\keys.ini:
    code_server = auto
    code_server = off
    code_server = https://your.server.example
  The last form is for a code server of your own (the same program on a rented server); the launcher shows it as
  "custom" with its name, and you type the address in keys.ini itself.
- What the code server keeps: each player's addresses (as the game sends them, and the address it sees), only while
  a room is open: at most 15 minutes waiting for player 2, then at most 30 minutes; deleted when the room closes.
  It writes no logs. The game's logs show room codes as their last two digits only (room ***13).

From test 15: straight into the character select
- Host and Join: both games now go straight to the VS character select: a few seconds of black screen, then the
  select. Nobody leads through the menus any more.
- A button held when the select appears does nothing until you let go of it; then pick as usual.
- If the other PC is slower, you see the select and "Waiting for player 2..." (or 1) until it is there.
- The old start (player 1 leads through the menus): set "PS2X_NETPLAY_START=menus" in the Host or Join .bat file, on
  either PC; then both start the old way.

From test 15: the key test shows an arcade stick
- F1 > Change keys > Test keys and controllers now shows a PlayStation arcade stick, as Hori, Mad Catz and Qanba PS
  sticks have it: Square, Triangle, R1, L1 on top, Cross, Circle, R2, L2 below, the lever on the left (its ball goes
  where you push), Select and Start small at the top. Under the buttons: the game's names for the four it names
  (Square L, Triangle M, Circle H, Cross RG) and the PS2 names for L1, R1, R2 and L2 (R2 and L2 stay dim unless
  something presses them).
- "Picture: arcade stick" on that page (click it), or "Picture in the test" on the Change keys page, switches to the
  controller picture and back. Your choice is kept in data\keys.ini.

From test 15: several buttons on one key or controller button
- F1 > Change keys > Several buttons on one key or controller button. Choose Add and press the key, mouse button,
  controller button or trigger. Then turn on the buttons it should press (Enter), for example L1 and R1, and choose
  Keep: "R presses L1 + R1". The buttons reach the game together, on the same frame.
- To undo it, choose its line on that page, then Clear: it presses its own button again.
- For the keyboard it is kept in data\keys.ini (a line such as "combo = R: l1 + r1"); for a controller in
  data\controller_buttons.txt, for that controller only. Start, Select, Guide and the d-pad of a controller keep
  their own buttons, because the menus need them.
- The key test lights every button such a press reaches and says so, for example "R: L1 + R1" or "R2 (button 7):
  L1 + R1".
- The game's own controller setting (OPTION in the game) still decides what each PS2 button does.
- Netplay is not affected: the other player's game gets the buttons you press, as always.

From test 15: practice mode
Start
- Double-click ps2run.exe: the launcher has "Practice (against the dummy)" on its start page. Choose player 1's and
  player 2's character and colour (Saber's fourth colour is Saber Lily) and the stage (Random, or 1 to 10), then
  "Start practice". The launcher remembers your choices (data\launcher.ini).
- The first start comes from power-on and takes a little longer; later starts and every swap begin at the select
  screen the game keeps in data\cache (made on your PC, from your disc; never share it).
- A .bat file can do the same, for example (one line):
  "%HERE%ps2run.exe" --disc "%ISO%" --game-dir "%HERE%data" --window
    --practice "p1=saber:lily,p2=archer:1,stage=random"

In the game: F1 > Practice (on a controller: hold Select, press Start; or Guide)
- Practice is the line after Resume, already highlighted: press Enter (Cross) once more. In a practice fight a
  tap of Start (Esc on the keyboard) opens this menu too; its first page also has Move list and the game's own
  PRACTICE MENU (test 19).
- Slot 1 to 4, Save the fight to the slot, Load the slot.
- Record player 2 for at most 1 to 60 seconds: your controller drives player 2 while you stand.
- Play the recording once or looped. Recording and playback begin where the fight is, or at a slot's moment.
- The dummy: CPU ACTION, GUARD (with 1ST HIT ONLY), THROW BREAK, COUNTER HIT, life and magic gauge recovery, HOLY
  GRAIL, recovery in the air and on the ground (the game's passive moves; see "From test 19").
- Characters and stage: swap player 1 or 2, their colours, or the stage (a few seconds without a picture).
- Input history on or off; frame data on or off (test 16); the move list (test 17; every character in test 18); the
  stick display (test 18; as an arcade stick in test 19); all of it remembered, with a line for the defaults
  (test 19).
- The game's own PRACTICE MENU opens from our menu's first page (test 19); its KEY REPLAY and INPUT DISPLAY
  still work. With keys.ini practice_start = game, Start in the fight opens it as before.

Quick keys (only in practice)
- Keyboard: F6 save to the slot, F7 load it, F3 record (again: stop), F10 play (again: stop).
- Controller or stick: hold Select and press Square (save), Triangle (load), Circle (record / stop),
  Cross (play / stop), Left or Right (the slot). A lone Select still reaches the game when you let go of it: the
  game's reset (never onto a recording: test 19).
- What a key did shows at the bottom of the window for a few seconds; so does REC (time left) or PLAY.

Input history
- Player 1 at the left edge, player 2 at the right, newest on top: the lever, the eight buttons in two rows of four
  as on the stick display (test 19; 8 lines), and how many frames each line lasted. It shows what the game got, so
  player 2's side shows a playback.

Stick display (test 18; the arcade layout in test 19)
- At the bottom left (player 1) and the bottom right (player 2): the lever as an 8-way gate and the eight buttons in
  two rows of four, in your device's names and colours, filled while pressed. See "From test 19".

From test 19: the arcade stick layout, remembered practice settings, Start for the menu and the dummy's recovery
(all described above). From test 18: every character's move list (described above) and the first stick display. From
test 17: Main Menu ends the session (described above). From test 16: IPv6, more routers, the home network line in
Join, frame data and throw breaks (all described above). From test 15: 5-digit room codes, straight into the
character select, the arcade stick in the key test, several buttons on one key, and practice mode (all described
above). From test 14: both players vote after a match (see "After a match"), F1 > Change keys > Test keys and
controllers, Resolution: auto (2x at 720 lines, 3x at 1080, 4x at 1440 and more), joining the other player when you
both chose Host, and every way of quitting you choose ends the program normally. From test 13: the launcher
(double-click ps2run.exe; the .bat files are still there as a way back), and the game takes your screen's shape
(auto by default, any shape from 4:3 to 32:9; players with different shapes play together, each with their own
view). From test 12: controllers: unplug and plug back in at any time, F1 > Controllers (XInput or DirectInput,
button layouts, which controller plays), DirectInput pads and fight sticks without a known layout, and
gamecontrollerdb.txt. From test 11: players with different widescreen settings stay the same frame for frame, so a
difference counts as a desync almost at once ("When the two games differ" on the Host and Join pages brings back
test 10's 5 seconds). From test 10: netplay.frames.txt in the report zip (the game's record of every frame), and a
game that runs late in a fight holds the next frame back until the fight has caught up. From test 9: no desync at
the start of a round with different widescreen settings, player 2 kept track of with Caster or Berserker as player
1. From test 8: the game no longer stops for a tenth of a second now and then (a timer fault in the port). From test
7: widescreen (built on nemesis2000's 16:9 patch for this disc, from PCSX2's patch collection; menus, health bars
and text are stretched, movies keep their shape), the picture settings, and the connection report after every match.
From test 6: connecting with codes, without port forwarding in most homes. From test 5: the freeze fix and the
freeze watchdog.

Setup
-----
1. Right-click the zip, Properties, tick Unblock, OK. Then extract it.
2. Put your own disc image of Fate/unlimited codes (Japan, SLPM-55108) into the FateUC-RollbackTest-25 folder, or
   into the folder above it. Any file name ending in .iso works. Elsewhere is fine too: the launcher lets you pick
   it.
3. Double-click FateUC.exe, the launcher (since test 21; "The game's own window" below is what ps2run.exe opens).
   The programs are not signed: Windows SmartScreen may warn - More info, then Run anyway. If Windows asks whether
   ps2run.exe may use the network, allow it.

The game's own window (ps2run.exe)
----------------------------------
ps2run.exe opens the game's own launcher window (FateUC.exe, new in test 21, does the same and more). Up and down
choose a line, left and right change a setting, Enter (or Cross on a controller, or a click) chooses. Esc (or
Circle) goes back; on the first page it closes the window. The lines under the list say what the chosen line does.
Every choice is saved at once and kept for the next start.

- Play offline: the game on its own, without netplay.
- Practice (against the dummy): straight into a practice fight with the characters, colours and stage you choose
  (see "From test 15: practice mode"; test 19 remembers its settings and opens its menu with Start).
- Host online: you are player 1. Start hosting, after setting:
    Input delay                        auto (the ping and both PCs' speed: test 20) or 1 to 10 frames
    Hide my code and address           on: hidden on screen, for streaming (C still copies the code)
    After a match                      both players vote, or player 1 chooses (as before; for both players if
                                       either player picks it)
    Start at                           character select (straight there), or the menus (as before test 15; for
                                       both players if either player picks it)
    Desync trace in the report         only when asked after a desync, both players
    Only players with my screen shape  on: a player with another screen shape is refused (test 12's rule)
    When the two games differ          desync at once, or up to 5 seconds as in test 10; both players the same
    Field of view                      a test line: the shape's own, 0.65 or 0.75 (at 21:9, 0.75 is the 16:9 view)
- Join online: you are player 2. Start joining (the same lines, except the input delay: player 1's decides).
- Same-PC test: both players on this PC (see "Testing on one PC").
- Settings: for Play offline, Host and Join (saved in data\keys.ini). The same settings are in the F1 menu in the
  game; the last column says when a change made there takes effect. A change in the launcher counts from the game's
  start.

  Picture look        sharp, crisp or soft (F2 also switches)                  at once
  Smooth edges        on or off                                                at once
  Resolution          auto: the smallest that fills your screen's height       at the next start
                      (2x at 720 lines, 3x at 1080, 4x at 1440 and more; at    (locked in a session)
                      most 2x on a graphics chip built into the processor),
                      or 1x to 4x (higher needs a stronger graphics card)
  Text and menus      soft, sharp or sharpest                                  at the next start
  Widescreen          auto (your main screen's shape, shown as "auto (16:9)"), at the next start
                      off (4:3), 16:10, 16:9, 21:9 or 32:9                     (locked in a session)
  Full screen         on or off (F11 also switches)                            at once
  Sync to the screen  auto, mailbox, immediate or fifo: how pictures reach the at once (when the graphics card
                      screen. Immediate has the least delay but can tear;      offers it)
                      fifo never tears but can add delay
  Integer scaling     the picture is a whole multiple of the console's lines   at once
                      (black bars around it)
  Scanlines           dark lines between the console's lines, like an old TV   at once
                      (most even with integer scaling on)
  Controllers         all, XInput only or DirectInput only: use one kind when  at once
                      a controller shows up twice (DS4Windows, Steam Input,
                      fight sticks with two modes)
  Code server         auto (the game's own code server, shown by its name),    launcher only
                      off (only the long codes, as in test 14), or custom:
                      the https:// address on data\keys.ini's code_server line

- Disc: the disc image the launcher uses; choose it to pick another one.
- Reports: the last session's connection report, your report zips, a button that opens the reports folder, and
  "Check why the game closed".
- The .bat files still work as before (they show the old "Before the game" window first); they go away once the
  launcher has proven itself.

Play
----
- Player 1 double-clicks ps2run.exe and chooses Host online, then Start hosting. The game window shows a room code,
  5 digits in big type such as 48213, and under it the long code (16 letters and digits in four groups, such as
  K7QX-3MPA-9RTE-W2HC). C copies the room code (Triangle on a controller). Send it to player 2 in your chat.
- Player 2 double-clicks ps2run.exe and chooses Join online, then Start joining, types the 5 digits in the game
  window and presses Enter. If the window says the code server can't be reached, player 1 sends the long code
  instead: player 2 pastes it (Ctrl+V) and presses Enter, and everything below works as in test 14.
- If player 1's window says "Your router opened port 7000 for this game", nothing else is needed: the game asked
  the router to open the port (UPnP, PCP or NAT-PMP) while player 1 hosts, and closes it again when player 1 stops
  hosting. (If the
  game crashes or is ended from Task Manager, the router closes it by itself within an hour.)
- With the long code, if it doesn't connect at once, swap codes. Player 2's window now shows player 2's own code:
  "If it doesn't connect in a few seconds, send this code to player 1." Player 2 copies it (C) and sends it. Player
  1 presses Enter in the game window, pastes it (Ctrl+V) and presses Enter again. Both games then call each other at
  the same time, which gets them through many routers. Player 1's window shows "Getting through..." and the match
  starts a moment later. With a room code the two games do this by themselves, through the code server.
- If you both chose Host by mistake: either of you types the other's room code, or pastes the other's long code,
  in your own game window (see "From test 15: 5-digit room codes").
- A typo in a code is caught: the window says so. Each code is new every time you host or join: send the new one.
- If it still doesn't connect, both windows say why (for example two "strict" routers: routers that use a new port
  for every other computer they talk to; one strict router is tried for up to a minute). Then use a virtual LAN:
  both players join the same Radmin VPN, ZeroTier or Tailscale network, and player 2 types player 1's address in it
  (player 1's window shows it with the VPN's name). Forwarding UDP port 7000 on player 1's router to player 1's PC
  also works, as before.
- Both PCs on the same home network: player 2's Join box offers player 1's game (Tab joins it), and the room code
  works there too. With the long code, player 2 types player 1's local address instead of the code (on player 1's
  PC: open a command prompt, type ipconfig, and use the "IPv4 Address" line). Most routers can't connect you to your
  own internet address from inside; the windows say so when both PCs are behind the same router.
- A long code holds your internet address, and anyone who has a room code can take player 2's place: send codes
  only to the other player. For streaming: turn on "Hide my code and
  address" on the Host or Join page; codes then show as stars on screen, and C still copies them. The reports never
  contain long codes, and show a room code by its last two digits only.
- The input delay comes from the ping and both PCs' speed ("Input delay: auto" on player 1's Host page, in the feel
  the players chose: see "From test 20"; a number from 1 to 10 fixes it).
- Both games go straight to the VS character select ("Starting the match..." on the black screen before it), then
  both players choose characters. The
  game is Japanese: Circle confirms (B on an Xbox controller), Cross goes back. Every character is unlocked: the
  session makes its own memory card, so no save of yours is used or changed.
- Each player plays with their own controller (or keyboard). F1 opens a menu: Change keys sets your keys and tests
  them (Test keys and controllers), Controllers the controllers (see above); the game waits while it is open, and so
  does the other player's. F11 or Alt+Enter: full screen.

After a match
-------------
- The WINNER screen is the game's own, as before: either player's button goes on. Then, instead of player 1 choosing
  alone, both players vote: a panel over the game's menu shows Rematch, Character Select and Main Menu, your own
  cursor, both players' picks and 20 seconds counting down. Up and down (or the left stick) move your cursor; Circle
  picks, as in the game's menu.
- Main Menu: either player picks it, and the session ends at once: both games say who chose it, show the whole
  session's connection report and close by themselves (test 17; the old way: set "PS2X_POSTMATCH_MAINMENU=game").
- Character Select: either player picks it. The other player can then pick only Character Select or Main Menu
  (Rematch is greyed out), and at most 10 seconds are left. If they run out, it is Character Select.
- Rematch: only when both players pick it.
- If nothing is decided when the 20 seconds run out: Character Select.
- A pick can only move on: from Rematch to Character Select or Main Menu, and from Character Select to Main Menu,
  never back.
- The game then takes the choice by itself, the same way on both PCs. Let go of your buttons and the game is yours
  again.
- While the panel is up it takes the place of the connection report and the line in the corner; they come back after
  the vote.
- The old way (player 1 chooses in the game's menu): "After a match: player 1 chooses" on the launcher's Host, Join
  or Same-PC page (in a .bat file: the line set "PS2X_POSTMATCH_VOTE=0"). One player choosing it is enough: the
  session then runs the old way for both, and its log says so. The launcher remembers the choice.

What you will see
-----------------
- The line in the corner (F4 shows or hides it), and the window title after the version, show: ping, input delay
  (with Responsive or Smooth after it when it is auto), rollbacks per second (rb), the deepest rollback of the last
  second, frames ahead, and "rollback" (from the match's loading through the intros, the fights and the ends of the
  rounds) or "lockstep" (menus, character select, the match result: there both games wait for each other, with a
  delay that covers the ping). A Rematch that loads the match again switches to rollback at its loading too.
- In a rollback the game runs the last few frames again without picture or sound, so a short hitch can show.
  Effects that build on earlier pictures (afterimages, trails, flashes) can show a wrong frame or two, and a sound
  can start a little late or keep playing. The game itself stays the same on both PCs.
- After each match both games write a CONNECTION REPORT into the log and the session's files, and the launcher's
  Reports tab shows it (keys.ini after_match_report = screen shows it at the WINNER screen for 10 seconds, as test
  22 did; any key or button closes it sooner, and the key still counts in the game). For each player: the network
  (wired, Wi-Fi, VPN adapter, or unknown), the ping (average and worst), the packets that player sent (lost, late,
  jitter), how many frames that player's game waited for the other, rollbacks, slow frames and seconds below 60 fps.
  The last line says which side had the trouble, or "Both sides were steady." "Dropping frames ... in the game's own
  work" means that PC is too slow for the game; "outside the game's own work" means the time went elsewhere on that
  PC: the window, the graphics card or other programs. The Reports page of the launcher shows the last session's
  report again.
- What counts as trouble: 1 % of a player's packets lost, 3 % late (40 ms or more behind the fastest), jitter (a
  jump of 25 ms or more between two packets, or 6 ms on average), or 1 % of that player's frames slow (more than 1.2
  frames long, not counting waits for the other player or rollbacks). When one player is wired and the other on
  Wi-Fi, trouble on the way in to the Wi-Fi player is put down to that player's Wi-Fi. A ping of 150 ms or more is
  called distance, not either player's fault. Wi-Fi is recognised from Windows' adapter type; a Wi-Fi adapter behind
  a virtual switch (Hyper-V) or a VPN can show as wired or as VPN.
- When the other player leaves, their game freezes, or nothing arrives from them for 15 seconds, the corner line
  says why and the game closes after 5 seconds; the report for the whole session goes into the log (keys.ini
  after_match_report = screen shows it under the end message). A desync (the two games no longer match) also ends
  the session.
- In widescreen a fight against the CPU can go differently from the same fight in 4:3: the game skips some of a
  character's work while that character is outside the camera's view, and a wider view keeps characters in view.
  Damage, walls and the timer work the same. With the same shape on both PCs this can't desync; with different
  shapes the game never skips that work, at any view, so both games stay the same.
- With different screen shapes, a difference between the two games in effects or menus is noticed only once it
  reaches a fighter, the timer or a choice. Every character has been tried as player 1 at 21:9 against another
  character at 4:3, supers included (except Gilgamesh's and Luviagelita's, which the test didn't reach), and many
  pairs of shapes from 4:3 to 32:9 (3440x1440 and 2560x1080 among them), with no difference. Tell us which
  characters, stages and shapes you played.
- No replay is kept in this mode.

Testing on one PC
-----------------
Same-PC test, then Start both games, starts both players on this PC: player 1 (host) and, 3 seconds later, player 2
(join), connected to each other inside the PC (nothing goes over the internet). Each keeps its own settings and
logs, in data-p1 and data-p2. The two windows are put side by side, and when both games have closed the launcher
packs both reports.
- Player 1's view and player 2's view choose the two widescreen settings: auto, off (4:3), 16:10, 16:9, 21:9 or
  32:9. Two different views play with mixed views, the same view as one game, as online.
- "Player 1's settings" and "Player 2's settings" hold each player's picture and controller settings.
- After a match: both players vote, or player 1 chooses (as before), for both games.
- Port: the port player 1 waits on, inside this PC. Change it only if another program uses 7000.
- With two controllers, the first drives player 1 and the second player 2, whichever window is in front. With one
  controller, it drives player 1: click player 2's window and use the keyboard for player 2. In the vote after a
  match each window's panel shows that window's player.
- Both games play sound (turn one down in the Windows volume mixer), and two games need about twice the CPU and
  graphics power: keep the resolution at 1x for this test (Resolution in each player's settings; auto would give
  both games your screen's resolution).
- "Same PC test - 21x9 vs 4x3.bat" still does the same (VIEW1 and VIEW2 at its top), as a way back.

Reporting
---------
Keep the launcher open while you play: when the game closes, it packs this PC's session into
reports\rollback_test_<date>_<time>_p1.zip (_p2 for player 2) and shows where it is. IP addresses and typed host
names are replaced by x.x.x.x, and your Windows user folder by %USERPROFILE%. The zip also holds
connection_report.json: the numbers of every match of the session, with no addresses and no codes, and
session.json with its codes emptied. With different
screen shapes it also holds netplay.frames.txt (and netplay.frames.old.txt in a long session): the game's record of
every frame.

Press Report a problem in the launcher, or open an issue at https://github.com/PureFighter/fateuc-native/issues with
the "Report" template and put "Release 1.3" in the title. Issues there are public: never attach game files, disc
images or .state files. Attach BOTH players' zips, and write:
- how you connected (a room code, player 1's long code alone, swapped codes, the home network line, IPv6, a VPN, or
  port forwarding), how long it took (the report files hold what each side's router and IPv6 allow),
  any message the window showed about the room code, and both players' screen shapes (the launcher's Widescreen
  setting, and the screens' sizes);
- the connection report's last line after the matches, and whether it matched what you felt;
- the launcher's version (Settings > About); in a room: whether you played, watched or practised,
  and what the Room tab showed; the ping, the input delay and the feel (Responsive or
  Smooth) from the corner line, whether the delay changed
  after the first round, and how the fights felt: input lag, hitches, characters jumping, sound; if you tried both
  feels, which one you liked at your distance;
- the vote after each match: what each of you picked, and whether the game went where the panel said; after Main
  Menu, whether both games closed by themselves and your launcher came back;
- with an arcade stick, or several buttons on one key: what you set, and whether the key test and the game did
  what you set;
- how many seconds the start to the character select took, on both PCs;
- for practice mode: whether the quick keys clash with anything on your stick or keyboard, whether the input history
  is readable at your screen size, and anything you set in our menu that looks different in the game's own PRACTICE
  MENU; a move whose frame data looks wrong to you (what you did, and what the panel said); a name or input in
  a move list that doesn't match the game; for the stick display and the input history:
  whether the names and colours match your device and read well at your screen size; whether the dummy's recovery
  and the game's own PRACTICE MENU from ours do what you expect; whether your practice settings came back;
- anything wrong on screen right after hits or round changes, or at the sides in widescreen;
- any freeze (whose game stopped, and what the other player's corner line said), any DESYNC, any session that ended
  by itself (with the reason shown), any crash;
- your CPU, graphics card and Windows version, and whether either player was on Wi-Fi.

If the game closed by itself (a crash, or the other player's game stopped), the launcher says how it ended, the zip
also says it (exit.txt) and holds what Windows recorded about it (windows_events.txt: crashes, closing while "not
responding", graphics driver resets). "Check why the game closed" (after such an ending, and on the Reports page)
looks up the same Windows records for the last 3 days and writes crash_check_<date>_<time>.txt; send that file too
if you are asked.

After a desync, data\logs also keeps .state files (copies of the game's memory). They are not put in the zip, and
they never go into a public issue: if one is needed, you will be asked for a private way. If asked for a trace, both
players turn on "Desync trace in the report" (Host or Join page) before the next session.

Files
-----
FateUC.exe                    the launcher (with FateUC.Launcher.exe and LICENSE-pnr.txt); its own files go into
                              launcher\ (settings.json, profile.json, history.jsonl, launcher.log)
ps2run.exe                    the game's own window, and the game's code translated for PC with the rollback test
CREDITS.txt                   who built this port, and what it is built on
SDL2.dll                      window, sound and controllers
gamecontrollerdb.txt          the community list of controller button layouts (SDL_GameControllerDB)
dxcompiler.dll, dxil.dll      Microsoft's DirectX shader compiler
tools\make_report.ps1         packs the report
tools\exit-codes.json         the words for the game's exit codes (the launcher and the report read them)
tools\check_crash.ps1         looks up Windows' records of crashes ("Check why the game closed")
tools\same_pc_test.ps1        starts both players for "Same PC test - 21x9 vs 4x3.bat"
data\                         made at the first start: logs, settings (keys.ini), the session's memory cards, caches
                              (data-p1\ and data-p2\ for the test on one PC)
data\launcher.ini             the launcher's choices (your disc, the Host, Join and Same-PC pages, "After a match")
data\controller_buttons.txt   several buttons on one controller button (made when you set one)
data\cache\                   the practice start's select screen, made on your PC from your disc (never share it)
*.bat                         the old way to start (Host, Join, Same PC test, Check why the game closed)
licenses\                     the licences of the code in this package (ps2-native-recomp, GekkoNet, zpp_bits,
                              miniupnpc, wgpu-native, SDL2, the DirectX shader compiler and dxil.dll, Play!'s
                              MPEG tables, SDL_GameControllerDB)
