@echo off
rem Looks in Windows' own records for why the game (ps2run.exe) ended: crashes, closing while "not responding", and
rem graphics driver resets, over the last 3 days. Needs no administrator rights. Writes crash_check_<date>_<time>.txt
rem in this folder and opens it; send that file with your report.
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\check_crash.ps1"
pause
