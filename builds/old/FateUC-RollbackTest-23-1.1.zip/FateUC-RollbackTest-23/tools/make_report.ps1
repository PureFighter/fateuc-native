# Packs this PC's newest rollback-test session (data\logs\rollback_test_<date>_<time>_p1 or _p2) and the program's log
# of the same run into reports\<session>.zip, to attach to an issue. The .state files (copies of the game's memory,
# kept only after a desync) are left out. IP addresses and typed host names become x.x.x.x and the Windows user folder
# %USERPROFILE% before the zip is made. Without a session (the game stopped before one began) the program's log alone
# is packed. The two .bat files run this when the game closes, with the program's exit code in EXITCODE: exit.txt in the zip says
# how the program ended, and windows_events.txt holds what Windows recorded about it since the run began (crashes,
# closing while "not responding", graphics driver resets; tools\check_crash.ps1).
# (W2 round 20) The exit words come from tools\exit-codes.json, the package's one table (the game's window and the launcher
# read it too); the words below are kept for a package without it. session.json (what the launcher shows) is packed with
# its two code fields emptied; session.json.tmp (a copy being written) is left out.
param([Parameter(Mandatory = $true)][string]$Data, [string]$Role = '', [string]$ExitCode = '')
$ErrorActionPreference = 'Stop'

# Files are read and written as Latin-1 so every byte stays as it was (the program writes UTF-8).
$latin1 = [Text.Encoding]::GetEncoding(28591)
$profileForms = @()
if ($env:USERPROFILE) {
    foreach ($encoding in @([Text.Encoding]::Default, [Text.Encoding]::UTF8)) {
        $form = $latin1.GetString($encoding.GetBytes($env:USERPROFILE))
        if ($profileForms -notcontains $form) { $profileForms += $form }
    }
}

function Hide-Private([string]$text) {
    # an address player 2 typed (it can be a host name), then every IPv4 address except this PC's loopback 127.0.0.1
    # (four numbers of 0-255 only, so version numbers such as a driver's 32.0.15.6094 stay)
    $text = [regex]::Replace($text, '(?<=joining |calling |connected to player 1 at |join:)(?!127\.0\.0\.1\b)[^\s(,;"]+', 'x.x.x.x')
    $text = [regex]::Replace($text, '(?<=cannot find the address ")[^"]*', 'x.x.x.x')
    # (W2 round 20b) what player 2 typed, in the two other failures that quote it: a wrong port, and "not a code"
    $text = [regex]::Replace($text, '(?<=bad port in ")[^"\r\n]*', 'x.x.x.x')
    $text = [regex]::Replace($text, '(?<=")[^"\r\n]*(?=" is not a code)', 'x.x.x.x')
    $octet = '(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)'
    $text = [regex]::Replace($text, '(?<![\d.])(?!127\.0\.0\.1(?!\d|\.\d))(?:' + $octet + '\.){3}' + $octet + '(?!\d|\.\d)', 'x.x.x.x')
    foreach ($form in $profileForms) {
        $text = [regex]::Replace($text, [regex]::Escape($form), '%USERPROFILE%', 'IgnoreCase')
    }
    return $text
}

try {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $Data = (Resolve-Path -LiteralPath $Data).Path
    $logs = Join-Path $Data 'logs'
    if (-not (Test-Path -LiteralPath $logs)) {
        Write-Host "No logs yet in $logs"
        exit 1
    }
    # The program's log of this run is the newest ps2run_*.log; it starts before the session's folder is made.
    $programLog = Get-ChildItem -LiteralPath $logs -Filter 'ps2run_*.log' -File | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    $sessions = @(Get-ChildItem -LiteralPath $logs -Directory | Where-Object {
            $_.Name -match '^rollback_test_\d{8}_\d{6}_p[12]$' -and ($Role -eq '' -or $_.Name.EndsWith('_' + $Role)) })
    $session = $sessions | Sort-Object Name -Descending | Select-Object -First 1
    if ($session -and $programLog -and $session.CreationTime -lt $programLog.CreationTime.AddSeconds(-5)) { $session = $null }  # an older run's
    if (-not $session -and -not $programLog) {
        Write-Host "Nothing to pack in $logs"
        exit 1
    }
    $name = if ($session) { $session.Name } else { [IO.Path]::GetFileNameWithoutExtension($programLog.Name) }
    $reports = Join-Path (Split-Path -Parent $Data) 'reports'
    $stage = Join-Path $reports $name
    if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
    [IO.Directory]::CreateDirectory($stage) | Out-Null
    if ($session) {
        foreach ($file in @(Get-ChildItem -LiteralPath $session.FullName -File)) {
            if ($file.Extension -ieq '.state' -or $file.Name -ieq 'netplay_last_host.txt' -or $file.Extension -ieq '.tmp') { continue }
            Copy-Item -LiteralPath $file.FullName -Destination $stage
        }
        $sessionFile = Join-Path $stage 'session.json'
        if (Test-Path -LiteralPath $sessionFile) {
            # the room code and the long code: kept only by the game while player 1 waits; never in a report
            $text = [IO.File]::ReadAllText($sessionFile, $latin1)
            $clean = [regex]::Replace($text, '("(?:code|long_code)"\s*:\s*)"(?:[^"\\]|\\.)*"', '$1""')
            if ($clean -cne $text) { [IO.File]::WriteAllText($sessionFile, $clean, $latin1) }
        }
    }
    if ($programLog) { Copy-Item -LiteralPath $programLog.FullName -Destination $stage }
    if ($ExitCode -eq '' -and $env:EXITCODE) { $ExitCode = $env:EXITCODE }  # the .bat sets EXITCODE (a negative number can't follow -ExitCode safely)
    if ($ExitCode -match '^-?\d+$') {
        $code = [int32]$ExitCode
        $hex = '0x{0:X8}' -f [BitConverter]::ToUInt32([BitConverter]::GetBytes($code), 0)
        $meaning = $null
        $table = Join-Path $PSScriptRoot 'exit-codes.json'
        if (Test-Path -LiteralPath $table) {
            try {
                $words = [IO.File]::ReadAllText($table, [Text.Encoding]::UTF8) | ConvertFrom-Json
                if ("$($words.format)" -like 'fateuc-exit-codes 1*') {
                    $entry = @($words.codes) | Where-Object { [int64]$_.code -eq [int64]$code -or "$($_.hex)" -eq $hex } | Select-Object -First 1
                    if ($entry -and $entry.words) { $meaning = "$($entry.words)" }
                    elseif ($words.other) { $meaning = "$($words.other)".Replace('{hex}', $hex) + ' (see windows_events.txt)' }
                }
            } catch { $meaning = $null }
        }
        if (-not $meaning) { $meaning = switch ($hex) {
            '0x00000000' { 'the program ended normally' }
            '0x00000001' { 'ended from outside (Task Manager "End task" gives 1) or a start-up error shown above' }
            '0x00000003' { 'abort() in the C library' }
            '0xC0000005' { 'access violation (a crash; the log normally has [crash] lines)' }
            '0xC0000409' { 'the program was stopped by a safety check it could not catch (fail-fast: a failed check or a library abort)' }
            '0xC0000374' { 'heap corruption detected by Windows' }
            '0xC00000FD' { 'stack overflow' }
            '0xC000013A' { 'ended with Ctrl+C or by closing the black window' }
            default { 'see windows_events.txt' }
        } }
        [IO.File]::WriteAllText((Join-Path $stage 'exit.txt'), "exit code $code ($hex): $meaning`r`n")
        Write-Host "The program's exit code: $code ($hex): $meaning"
    }
    $checker = Join-Path $PSScriptRoot 'check_crash.ps1'
    if ((Test-Path -LiteralPath $checker) -and $programLog) {
        try {
            & $checker -Since $programLog.CreationTime.AddMinutes(-1).ToString('s') -Out (Join-Path $stage 'windows_events.txt') | Out-Null
        } catch { }
    }
    foreach ($file in @(Get-ChildItem -LiteralPath $stage -File)) {
        $text = [IO.File]::ReadAllText($file.FullName, $latin1)
        $clean = Hide-Private $text
        if ($clean -cne $text) { [IO.File]::WriteAllText($file.FullName, $clean, $latin1) }
    }
    $zip = Join-Path $reports ($name + '.zip')
    if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force }
    [IO.Compression.ZipFile]::CreateFromDirectory($stage, $zip)
    Remove-Item -LiteralPath $stage -Recurse -Force
    $size = [math]::Ceiling((Get-Item -LiteralPath $zip).Length / 1KB)
    Write-Host "Report saved: $zip ($size KB)"
    if (-not $session) { Write-Host 'No rollback test session was found for this run: the zip holds the program''s log only.' }
    Write-Host 'To report a problem, attach this zip and the other player''s to an issue on the test repository.'
    exit 0
}
catch {
    Write-Host "Couldn't make the report: $($_.Exception.Message)"
    exit 2
}
