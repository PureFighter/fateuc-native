# Looks in Windows' own records for why ps2run.exe (the Fate/UC test program) ended: crashes, programs closed while
# "not responding", and graphics driver resets, over the last few days. Needs no administrator rights. Writes
# crash_check_<date>_<time>.txt next to the .bat file that runs it and opens it in Notepad. The Windows user folder
# becomes %USERPROFILE%.
#   -Days <n>     how far back to look (3)
#   -Since <time> look from this time instead (as the report script does: the start of the run)
#   -Out <file>   write here and don't open Notepad (the report script uses this)
param([int]$Days = 3, [string]$Since = '', [string]$Out = '')
$ErrorActionPreference = 'Continue'
$from = if ($Since) { [datetime]$Since } else { (Get-Date).AddDays(-$Days) }
$lines = New-Object System.Collections.Generic.List[string]
$found = 0
$lines.Add("Windows' records about ps2run.exe and the graphics driver since $($from.ToString('yyyy-MM-dd HH:mm:ss')) (this PC's clock)")
$lines.Add("Windows $([Environment]::OSVersion.Version)")
$lines.Add('')

function Add-Event($e, [string]$what) {
    $script:found++
    $lines.Add("== $($e.TimeCreated.ToString('yyyy-MM-dd HH:mm:ss'))  $what (event $($e.Id), $($e.LevelDisplayName))")
    $lines.Add(($e.Message -replace "`r", ''))
    $lines.Add('')
}

# Application log: 1000 "Application Error" (a crash, with its exception code and the module it happened in),
# 1001 "Windows Error Reporting" (the same crash as a report), 1002 "Application Hang" (closed while not responding)
foreach ($spec in @(@{ P = 'Application Error'; Id = 1000 }, @{ P = 'Windows Error Reporting'; Id = 1001 }, @{ P = 'Application Hang'; Id = 1002 })) {
    $events = @()
    try { $events = @(Get-WinEvent -FilterHashtable @{ LogName = 'Application'; ProviderName = $spec.P; Id = $spec.Id; StartTime = $from } -ErrorAction Stop) } catch { }
    foreach ($e in $events) { if ($e.Message -match 'ps2run') { Add-Event $e $spec.P } }
}
# System log: graphics driver resets and errors ("Display" 4101: the driver stopped responding and recovered;
# nvlddmkm for NVIDIA, amdkmdag/amdwddmg for AMD, igfx for Intel)
foreach ($p in @('Display', 'nvlddmkm', 'amdkmdag', 'amdwddmg', 'igfx', 'igfxn')) {
    $events = @()
    try { $events = @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; ProviderName = $p; StartTime = $from } -ErrorAction Stop) } catch { }
    foreach ($e in $events) { if ($e.Level -le 3) { Add-Event $e "graphics driver ($p)" } }
}
# Windows Error Reporting's own files: the exception code, the module and the offset of a crash
foreach ($root in @("$env:ProgramData\Microsoft\Windows\WER\ReportArchive", "$env:ProgramData\Microsoft\Windows\WER\ReportQueue",
        "$env:LOCALAPPDATA\Microsoft\Windows\WER\ReportArchive", "$env:LOCALAPPDATA\Microsoft\Windows\WER\ReportQueue")) {
    if (-not (Test-Path -LiteralPath $root)) { continue }
    foreach ($d in @(Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'ps2run' -and $_.LastWriteTime -ge $from })) {
        $wer = Join-Path $d.FullName 'Report.wer'
        if (-not (Test-Path -LiteralPath $wer)) { continue }
        $found++
        $lines.Add("== $($d.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss'))  Windows error report $($d.Name)")
        foreach ($l in @(Get-Content -LiteralPath $wer -Encoding Unicode -ErrorAction SilentlyContinue)) {
            if ($l -match '^(EventType|FriendlyEventName|AppPath|Sig\[\d+\]\.(Name|Value)|DynamicSig\[\d+\]\.(Name|Value))=') { $lines.Add($l) }
        }
        $lines.Add('')
    }
}
if ($found -eq 0) {
    $lines.Add('Nothing found. Windows records every crash of a program, including the ones a program cannot catch itself, and')
    $lines.Add('every program closed while "not responding". When it has nothing, ps2run.exe was most likely ended from outside')
    $lines.Add('(Task Manager "End task", or the power or a restart), or error reporting is switched off on this PC.')
}

$text = ($lines -join "`r`n")
if ($env:USERPROFILE) { $text = [regex]::Replace($text, [regex]::Escape($env:USERPROFILE), '%USERPROFILE%', 'IgnoreCase') }
$open = -not $Out
if (-not $Out) { $Out = Join-Path (Split-Path -Parent $PSScriptRoot) ('crash_check_' + (Get-Date).ToString('yyyyMMdd_HHmmss') + '.txt') }
[IO.File]::WriteAllText($Out, $text + "`r`n", [Text.Encoding]::UTF8)
Write-Host "Found $found record(s); written to $Out"
if ($open) { Start-Process notepad.exe -ArgumentList ('"' + $Out + '"') }
