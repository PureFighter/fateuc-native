# Same-PC test of Release 1 (test 23), started by "Same PC test - 21x9 vs 4x3.bat": player 1 (host) and player 2 (join, to
# 127.0.0.1) on this PC, each with its own data folder (data-p1, data-p2); different shapes play mixed views by
# themselves. The two game windows are put side by side; when both games have closed, both reports are packed
# (tools\make_report.ps1).
param(
    [Parameter(Mandatory = $true)][string]$Iso,
    [string]$View1 = '21:9',
    [string]$View2 = 'off',
    [int]$Port = 7000,
    [string]$Exe = ''
)
$ErrorActionPreference = 'Stop'
$tools = $PSScriptRoot
$here = Split-Path -Parent $tools
if ($Exe -eq '') { $Exe = Join-Path $here 'ps2run.exe' }
$data1 = Join-Path $here 'data-p1'
$data2 = Join-Path $here 'data-p2'

function Quote([string]$text) { '"' + $text + '"' }
function ViewName([string]$view) { if ($view -eq 'off') { '4:3' } else { $view } }

# Start-Process joins the arguments with spaces, so the paths are quoted here. Both games write into this window.
$env:PS2_WINDOW_TITLE = 'Player 1 (host, ' + (ViewName $View1) + ')'
$p1 = Start-Process -FilePath $Exe -NoNewWindow -PassThru -ArgumentList @(
    '--disc', (Quote $Iso), '--game-dir', (Quote $data1), '--window', "--widescreen=$View1",
    '--netplay', "host:$Port", '--netplay-rollback', '--netplay-delay', 'auto', '--netplay-no-upnp', '--netplay-pad', '0')
$null = $p1.Handle  # keeps the exit code readable after the game closes
Start-Sleep -Seconds 3
$env:PS2_WINDOW_TITLE = 'Player 2 (join, ' + (ViewName $View2) + ')'
$p2 = Start-Process -FilePath $Exe -NoNewWindow -PassThru -ArgumentList @(
    '--disc', (Quote $Iso), '--game-dir', (Quote $data2), '--window', "--widescreen=$View2",
    '--netplay', "join:127.0.0.1:$Port", '--netplay-rollback', '--netplay-pad', '1')
$null = $p2.Handle
Remove-Item Env:PS2_WINDOW_TITLE

# The game window of a process, once it is open (0 if the game closed first or none came within 30 seconds).
function Wait-GameWindow($process) {
    for ($i = 0; $i -lt 150; $i++) {
        if ($process.HasExited) { return [IntPtr]::Zero }
        $process.Refresh()
        if ($process.MainWindowHandle -ne [IntPtr]::Zero) { return $process.MainWindowHandle }
        Start-Sleep -Milliseconds 200
    }
    return [IntPtr]::Zero
}

# Both windows open in the middle of the screen, on top of each other: player 1 goes to the left, player 2 to its right.
try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -Namespace SamePcTest -Name Win -MemberDefinition @'
[System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool GetWindowRect(System.IntPtr window, out RECT rect);
[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool SetWindowPos(System.IntPtr window, System.IntPtr after, int x, int y, int width, int height, uint flags);
'@
    [void][SamePcTest.Win]::SetProcessDPIAware()  # screen pixels, the same as the game windows'
    $w1 = Wait-GameWindow $p1
    $w2 = Wait-GameWindow $p2
    if ($w1 -ne [IntPtr]::Zero -and $w2 -ne [IntPtr]::Zero) {
        Start-Sleep -Milliseconds 700  # the windows take their final size
        $r1 = New-Object 'SamePcTest.Win+RECT'
        $r2 = New-Object 'SamePcTest.Win+RECT'
        [void][SamePcTest.Win]::GetWindowRect($w1, [ref]$r1)
        [void][SamePcTest.Win]::GetWindowRect($w2, [ref]$r2)
        $width1 = $r1.Right - $r1.Left; $height1 = $r1.Bottom - $r1.Top
        $width2 = $r2.Right - $r2.Left; $height2 = $r2.Bottom - $r2.Top
        $area = [System.Windows.Forms.Screen]::FromHandle($w1).WorkingArea
        if ($width1 -lt $area.Width -and $width2 -lt $area.Width -and $height1 -le $area.Height -and $height2 -le $area.Height) {
            if ($width1 + $width2 -le $area.Width) {
                $x1 = $area.Left + [int][Math]::Floor(($area.Width - $width1 - $width2) / 2)
                $x2 = $x1 + $width1
            } else {
                $x1 = $area.Left  # a narrow screen: the windows overlap in the middle
                $x2 = $area.Right - $width2
            }
            $y1 = $area.Top + [int][Math]::Floor(($area.Height - $height1) / 2)
            $y2 = $area.Top + [int][Math]::Floor(($area.Height - $height2) / 2)
            $flags = [uint32](0x0001 -bor 0x0004 -bor 0x0010)  # keep the size and the order, don't take the focus
            [void][SamePcTest.Win]::SetWindowPos($w1, [IntPtr]::Zero, $x1, $y1, 0, 0, $flags)
            [void][SamePcTest.Win]::SetWindowPos($w2, [IntPtr]::Zero, $x2, $y2, 0, 0, $flags)
            Write-Host 'The game windows are side by side: player 1 on the left, player 2 on the right.'
        }
    }
} catch {
    Write-Host ('The windows could not be placed side by side (' + $_.Exception.Message + '): drag them apart.')
}

Write-Host 'Click a game window to give it the keyboard. When one game closes, the other closes a few seconds later.'
$p1.WaitForExit()
$p2.WaitForExit()

Write-Host ''
Write-Host 'Both games have closed. Packing the reports...'
$report = Join-Path $tools 'make_report.ps1'
$shell = (Get-Process -Id $PID).Path  # this PowerShell; make_report.ps1 ends with exit, so each side runs in its own
$env:EXITCODE = [string]$p1.ExitCode
& $shell -NoProfile -ExecutionPolicy Bypass -File $report -Data $data1 -Role p1
$env:EXITCODE = [string]$p2.ExitCode
& $shell -NoProfile -ExecutionPolicy Bypass -File $report -Data $data2 -Role p2
