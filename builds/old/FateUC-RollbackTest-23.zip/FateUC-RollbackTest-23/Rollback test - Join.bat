@echo off
rem Rollback netplay TEST (GekkoNet): you are player 2. A test version, separate from the usual netplay builds.
rem Player 1 runs "Rollback test - Host.bat" first and sends you the code its game window shows: paste it into this
rem game window (Ctrl+V) and press Enter. If it doesn't connect in a few seconds, send player 1 the code this game
rem window then shows (C copies it). Player 1's setting decides the input delay; with auto, your feel counts too.
rem Simpler: double-click ps2run.exe, the launcher, which offers every line below as a choice.
setlocal
cd /d "%~dp0"
set "HERE=%~dp0"
title Fate/unlimited codes - Release 1 (test 23) - player 2 (join)

rem With player 1's input delay on auto, the feel (test 20): responsive (the least delay both PCs keep up with) or
rem smooth (one frame more where that makes the pictures steadier). If either player chooses smooth, the session
rem plays smooth. The game remembers the last choice in data\keys.ini (auto_delay), which the Online tab of the
rem new launcher's Settings also sets. To choose here, remove "rem " in front of one of the next two lines.
set "FEEL="
rem set "FEEL=--netplay-auto-delay smooth"
rem set "FEEL=--netplay-auto-delay responsive"

set "HIDE="
rem To hide your code on screen and in this window (for streaming), remove "rem " in front of the next line;
rem C (Triangle on a controller) still copies it in the game window.
rem set "HIDE=--netplay-hide-address"

rem Only when asked after a desync: remove "rem " in front of the next line (both players), for a trace in the report.
rem set PS2X_ROLLBACK_TEST_TRACE=1
rem Only to compare fields of view at 21:9: remove "rem " in front of the next line. Without it the game uses your
rem shape's own view (0.5714 at 21:9); 0.65 shows a little less and stretches the picture by 1.14; 0.75 is the 16:9
rem view stretched to 21:9 by 1.31. Two players with different numbers (or one without the line) play mixed views.
rem set "PS2X_WIDESCREEN_FOV=0.65"
rem Players with different screen shapes (for example 21:9 and 4:3) play together by themselves: each one sees their
rem own view, and the game checks that the fights match. To play only against players with your shape (test 12's
rem rule), remove "rem " in front of the next line; a player with another shape is then refused, with the reason.
rem set "PS2X_MIXED_WIDESCREEN=0"
rem With different shapes, a difference between the two games is a desync almost at once. To let it last up to 5
rem seconds first, as in test 10, remove "rem " in front of the next line (both players).
rem set "PS2X_MIXED_RUN_RULE=old"
rem After a match both players vote. To keep the old way (player 1 chooses), remove "rem " in front of the
rem next line (one player's line is enough).
rem set "PS2X_POSTMATCH_VOTE=0"
rem After a match, Main Menu ends the session and the game closes (test 17). To keep the old way (both
rem games go to the game's main menu), remove "rem " in front of the next line (one player's line is enough).
rem set "PS2X_POSTMATCH_MAINMENU=game"
rem Both games go straight to the character select. To start the old way (player 1 leads through the
rem menus), remove "rem " in front of the next line (one player's line is enough).
rem set "PS2X_NETPLAY_START=menus"

rem Your disc image: the .iso dropped on this file, else the first .iso in this folder, else in the folder above.
set "ISO="
if not "%~1"=="" set "ISO=%~f1"
if not defined ISO for %%F in ("%HERE%*.iso") do if not defined ISO set "ISO=%%~fF"
if not defined ISO for %%F in ("%HERE%..\*.iso") do if not defined ISO set "ISO=%%~fF"
if not defined ISO goto no_iso
if not exist "%ISO%" goto no_iso
if not exist "%HERE%data" mkdir "%HERE%data"

rem The window before the game: picture settings and the last session's connection report.
"%HERE%ps2run.exe" --settings-window --game-dir "%HERE%data"
if errorlevel 1 (
  echo You chose Quit in the window before the game: the game does not start.
  exit /b 0
)

echo Disc image: "%ISO%"
echo Joining the rollback test as player 2: paste player 1's code in the game window and press Enter.
echo Keep this window open: it packs the report when the game closes.
"%HERE%ps2run.exe" --disc "%ISO%" --game-dir "%HERE%data" --window --netplay join --netplay-rollback %FEEL% %HIDE%
set "EXITCODE=%ERRORLEVEL%"
echo.
echo The game has closed. Packing the report...
powershell -NoProfile -ExecutionPolicy Bypass -File "%HERE%tools\make_report.ps1" -Data "%HERE%data" -Role p2
pause
exit /b 0

:no_iso
echo Cannot find your disc image of Fate/unlimited codes (a file ending in .iso).
echo Put it in this folder, or drag it onto this .bat file:
echo   "%HERE%"
pause
exit /b 1
