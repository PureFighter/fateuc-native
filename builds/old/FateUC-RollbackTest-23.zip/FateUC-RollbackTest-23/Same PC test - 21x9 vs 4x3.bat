@echo off
rem Same-PC test of Release 1 (test 23): player 1 at 21:9 and player 2 at 4:3 play a rollback match on this PC, the two
rem games connected to each other through 127.0.0.1 (nothing goes over the internet). Different screen shapes play
rem together by themselves (mixed views), and each game has its own data folder (data-p1, data-p2).
rem Controllers: the first controller drives player 1 and the second drives player 2, whichever window is in front.
rem With one controller, it drives player 1: click player 2's window and use the keyboard for player 2 (F1, then Keys,
rem lists the keys). Player 1 leads through the menus to the two-player VS match; then both choose characters.
rem Both games play sound: turn one down in the Windows volume mixer if you like.
setlocal
cd /d "%~dp0"
set "HERE=%~dp0"
title Fate/unlimited codes - Release 1 (test 23) - same PC test

rem The two screen shapes: auto, off (4:3), 16:10, 16:9, 21:9, 32:9 or w:h. Two different shapes play with mixed
rem views; the same shape plays as one machine.
set "VIEW1=21:9"
set "VIEW2=off"
rem The port player 1 waits on, inside this PC only. Change it if another program uses it.
set "PORT=7000"
rem A difference between the two games is a desync almost at once. To let it last up to 5 seconds first, as in
rem test 10, remove "rem " in front of the next line.
rem set "PS2X_MIXED_RUN_RULE=old"

rem Your disc image: the .iso dropped on this file, else the first .iso in this folder, else in the folder above.
set "ISO="
if not "%~1"=="" set "ISO=%~f1"
if not defined ISO for %%F in ("%HERE%*.iso") do if not defined ISO set "ISO=%%~fF"
if not defined ISO for %%F in ("%HERE%..\*.iso") do if not defined ISO set "ISO=%%~fF"
if not defined ISO goto no_iso
if not exist "%ISO%" goto no_iso
if not exist "%HERE%data-p1" mkdir "%HERE%data-p1"
if not exist "%HERE%data-p2" mkdir "%HERE%data-p2"

echo Disc image: "%ISO%"
echo Player 1 (host) with widescreen %VIEW1% and player 2 (join) with widescreen %VIEW2%, both on this PC.
echo Keep this window open: it packs both reports when the games close.
powershell -NoProfile -ExecutionPolicy Bypass -File "%HERE%tools\same_pc_test.ps1" -Iso "%ISO%" -View1 "%VIEW1%" -View2 "%VIEW2%" -Port %PORT%
pause
exit /b 0

:no_iso
echo Cannot find your disc image of Fate/unlimited codes (a file ending in .iso).
echo Put it in this folder, or drag it onto this .bat file:
echo   "%HERE%"
pause
exit /b 1
